# People

## Project Lead

Philipp Rudiger (@philippfr)

## Maintainers

- Philipp Rudiger (@philippfr)
- Simon Hansen (@Hoxbro)
- Maxime Liquet (@maximlt)
- Marc Skov Madsen (@MarcSkovMadsen)
- Andrew Huang (@ahuang11)

## Steering Committee

The Panel project is governed by the [HoloViz steering committee](https://github.com/holoviz/holoviz/blob/main/doc/governance/org-docs/STEERING-COMMITTEE.md).

## CoC Subcommittee

- James A. Bednar (@jbednar)
- Sophia Yang (@sophiamyang)
- Philipp Rudiger (@philippjfr)

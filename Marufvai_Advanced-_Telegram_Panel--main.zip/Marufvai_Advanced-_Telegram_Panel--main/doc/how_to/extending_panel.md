.. raw:: html
    <head>
        <meta http-equiv='refresh' content='0; URL=./index.html#extending-panel>
    </head>

# Extending Panel

```{toctree}
:titlesonly:
:hidden:
:maxdepth: 1

Create Custom Components<custom_components/index>
```

.. raw:: html
    <head>
        <meta http-equiv='refresh' content='0; URL=./index.html#migrate-to-panel'>
    </head>

# Migrate to Panel

```{toctree}
:titlesonly:
:hidden:
:maxdepth: 1

Migrate from AnyWidget<migration/anywidget/index>
Migrate from Streamlit<streamlit_migration/index>
```

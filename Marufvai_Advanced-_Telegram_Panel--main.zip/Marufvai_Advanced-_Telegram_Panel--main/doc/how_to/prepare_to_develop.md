.. raw:: html
    <head>
        <meta http-equiv='refresh' content='0; URL=./index.html#prepare-to-develop'>
    </head>

# Prepare to develop

```{toctree}
:titlesonly:
:hidden:
:maxdepth: 1

Develop in a notebook<notebook/index>
Develop in an editor<editor/index>
```

.. raw:: html
    <head>
        <meta http-equiv='refresh' content='0; URL=./index.html#prepare-to-share'>
    </head>

# Prepare to share

```{toctree}
:titlesonly:
:hidden:
:maxdepth: 1

Apply Templates<templates/index>
Improve Performance<performance/index>
Cache Data<caching/index>
Improve Scalability<concurrency/index>
Best Practices <best_practices/index>
Add Authentication<authentication/index>
```

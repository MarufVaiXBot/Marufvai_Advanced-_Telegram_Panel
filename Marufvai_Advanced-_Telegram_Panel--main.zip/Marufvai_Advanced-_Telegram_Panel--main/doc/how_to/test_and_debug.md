.. raw:: html
    <head>
        <meta http-equiv='refresh' content='0; URL=./index.html#test-and-debug'>
    </head>

# Test and debug

```{toctree}
:titlesonly:
:hidden:
:maxdepth: 1

Enable profiling and debugging<profiling/index>
Set up testing for an application<test/index>
```

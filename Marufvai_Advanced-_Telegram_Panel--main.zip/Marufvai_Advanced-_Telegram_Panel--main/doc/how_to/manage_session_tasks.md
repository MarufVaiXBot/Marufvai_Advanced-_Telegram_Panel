.. raw:: html
    <head>
        <meta http-equiv='refresh' content='0; URL=./index.html#manage-session-tasks'>
    </head>

# Manage session tasks

```{toctree}
:titlesonly:
:hidden:
:maxdepth: 1

Register Session Callbacks<callbacks/index>
Access Session State<state/index>
```

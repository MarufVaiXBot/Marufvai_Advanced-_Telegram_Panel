.. raw:: html
    <head>
        <meta http-equiv='refresh' content='0; URL=./index.html#share-your-work'>
    </head>

# Share your work

```{toctree}
:titlesonly:
:hidden:
:maxdepth: 1

Configure the server<server/index>
Distribute applications<distribute/index>
Integrate with other servers<integrations/index>
Deploy applications<deployment/index>
Export apps<export/index>
Run panel in WebAssembly<wasm/index>
```

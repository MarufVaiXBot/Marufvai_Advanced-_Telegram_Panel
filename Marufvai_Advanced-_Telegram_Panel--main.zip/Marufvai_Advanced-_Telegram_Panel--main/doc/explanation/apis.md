.. raw:: html
    <head>
        <meta http-equiv='refresh' content='0; URL=./index.html#apis'>
    </head>

# APIs

```{toctree}
:titlesonly:
:hidden:
:maxdepth: 1

API context <api/index>
```

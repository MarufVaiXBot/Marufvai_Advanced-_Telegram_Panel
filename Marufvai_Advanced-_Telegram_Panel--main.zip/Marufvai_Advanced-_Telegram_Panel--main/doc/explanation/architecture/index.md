.. raw:: html
    <head>
        <meta http-equiv='refresh' content='0; URL=./index.html#architecture>
    </head>

# Architecture

```{toctree}
:titlesonly:
:hidden:
:maxdepth: 1

Communication Channels <comms>
```

.. raw:: html
    <head>
        <meta http-equiv='refresh' content='0; URL=./index.html#components'>
    </head>

# Components

```{toctree}
:titlesonly:
:hidden:
:maxdepth: 1

Components overview <components/components_overview>
Custom components <components/reactive_html_components>
```

.. raw:: html
    <head>
        <meta http-equiv='refresh' content='0; URL=../index.html#styling'>
    </head>

# Styling

```{toctree}
:titlesonly:
:hidden:
:maxdepth: 1

Design & Theme <design>
Templates <templates_overview>
```

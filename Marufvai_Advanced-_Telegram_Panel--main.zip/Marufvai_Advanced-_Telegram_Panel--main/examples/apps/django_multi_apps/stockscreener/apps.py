from django.apps import AppConfig


class StockscreenerConfig(AppConfig):
    name = 'stockscreener'

from django.apps import AppConfig


class GbmConfig(AppConfig):
    name = 'gbm'
